<?php get_header();?>

<div class="container">

  <?php query_posts('post_type=justificativas&post_per_page=-1') ?>

  <?php if(have_posts()): while(have_posts()): the_post();?>

  <div class="row justificativa justify-content-center">
    <div class="col-md-12">
      <table class="table-responsive-sm table-bordered table-success" style="text-align: center; vertical-align: middle;">

        <tbody>
          <tr>
            <td class="font-weight-bold">Solicitante</td>
            <td colspan="3"><?php the_author( ); ?></td>
            <td class="font-weight-bold">Tipo</td>
            <td><?php get_field('tipo') ?></td>
            <td class="font-weight-bold">Status</td>
            <td>Aguardando aprovação</td>
          </tr>
          <tr>
            <td class="font-weight-bold">Protocolo</td>
            <td>2019123456</td>
            <td class="font-weight-bold">Data</td>
            <td>24/01/2019</td>
            <td class="font-weight-bold">Horario de entrada</td>
            <td>19:00</td>
            <td class="font-weight-bold">Horario de saída</td>
            <td>07:00</td>
          </tr>
          <tr>
            <td class="font-weight-bold" rowspan="2">Justificativa</td>
            <td colspan="3" rowspan="2">Muita chuva, carro atolou, acabou a energia</td>
            <td class="font-weight-bold">Observação</td>
            <td colspan="3">Número da ocorrência 234556</td>
          </tr>
          <tr>
            <td colspan="4">
              <div class="input-group mb-3">
                <input type="text" placeholder="Motivo da recusa"  class="form-control" placeholder="" aria-label="Example text with two button addons" aria-describedby="button-addon3">
                <div class="input-group-prepend" id="button-addon3">
                  <button class="btn btn-danger" type="button">Recusar</button>
                  <button class="btn btn-success" type="button">Aceitar</button>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>



  <!--<a style="text-decoration: none;" href="<?php the_permalink();?>">
    <article class="row border-bottom border-warning noticia">
      <div class="col-md-4 div-capa">
          <?php the_post_thumbnail('medium_large',['class' => 'align-self-center mr-3 img-fluid card-img img-capa']); ?>
      </div>
      <div class="card-body col-md-8">
        <h6 class="text-muted"><?php the_date(); ?></h6>
        <h5 class="card-title "><?php the_title(); ?></h5>
        <p class="card-text"><?php the_excerpt(); ?></p>
      </div>
    </article>
  </a>-->

<?php endwhile; endif;?>



<div class="row justify-content-center">
  <div class="col-md-4 text-center">
    <?php posts_nav_link( ' | ', $prelabel, $nextlabel ); ?>
  </div>
</div></br>


</div>

<?php get_footer();?>
