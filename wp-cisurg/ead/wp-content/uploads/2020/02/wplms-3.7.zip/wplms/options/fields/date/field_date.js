jQuery(document).ready(function(){
	
	/*
	 *
	 * VIBE_Options_date function
	 * Adds datepicker js
	 *
	 */
	jQuery('.vibe-opts-datepicker').datepicker();
	
});